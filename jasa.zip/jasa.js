document.getElementById('cv-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Récupérer les données du formulaire
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    const education = document.getElementById('education').value;
    const experience = document.getElementById('experience').value;
    const skills = document.getElementById('skills').value;
    const languages = document.getElementById('languages').value;
    const hobbies = document.getElementById('hobbies').value;

    // Générer le CV
    const cvOutput = `
        <h2>Mon CV</h2>
        <p><strong>Nom :</strong> ${name}</p>
        <p><strong>Email :</strong> ${email}</p>
        <p><strong>Téléphone :</strong> ${phone}</p>
        <p><strong>Adresse :</strong> ${address}</p>
        <p><strong>Formation :</strong></p>
        <p>${education}</p>
        <p><strong>Expérience professionnelle :</strong></p>
        <p>${experience}</p>
        <p><strong>Compétences :</strong></p>
        <p>${skills}</p>
        <p><strong>Langues :</strong></p>
        <p>${languages}</p>
        <p><strong>Loisirs :</strong></p>
        <p>${hobbies}</p>
    `;

    document.getElementById('cv-output').innerHTML = cvOutput;

    // Afficher le bouton de téléchargement
    document.getElementById('download-btn').style.display = 'block';
});

// Fonction pour télécharger le CV
document.getElementById('download-btn').addEventListener('click', function() {
    const cvContent = document.getElementById('cv-output').innerHTML;
    const blob = new Blob([cvContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mon_cv.html';
    a.click();
});
